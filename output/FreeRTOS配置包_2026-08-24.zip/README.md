# chassis_motor 项目 FreeRTOS 配置包

生成日期：2026-08-24

本包提取了当前 `STM32F750V8Tx` 麦克纳姆轮底盘工程中与 FreeRTOS/CMSIS-RTOS2 相关的配置、内核源码、Cortex-M7 移植层、任务创建代码、时钟/中断集成文件和 Keil/CubeMX 工程信息。它用于备份、对照和迁移；没有包含整个 STM32 HAL/Drivers 工程。

## 1. 项目上下文

- 主控：STM32F750V8Tx，Cortex-M7。
- 电机：4 个闭环步进驱动器；运动控制仍由 `Motor/` 模块负责。
- IMU：JY60/JY61P，运动控制和姿态锁头由现有模块负责。
- FreeRTOS 接入方式：CMSIS-RTOS2 API（`cmsis_os2.c`）+ 原生 FreeRTOS Kernel。
- Keil 工程：`MDK-ARM/chassis_motor.uvprojx`。
- CubeMX 工程：`chassis_motor.ioc`。

## 2. 当前 FreeRTOS 配置摘要

| 配置项 | 当前值 | 说明 |
|---|---:|---|
| `configTICK_RATE_HZ` | `1000` | 1 ms FreeRTOS tick |
| `configUSE_PREEMPTION` | `1` | 抢占式调度 |
| `configMAX_PRIORITIES` | `56` | 最大任务优先级数量 |
| `configMINIMAL_STACK_SIZE` | `256` | 原生 FreeRTOS 栈单位为 word |
| `configTOTAL_HEAP_SIZE` | `32768` | 32 KiB，使用 `heap_4.c` |
| `configMAX_TASK_NAME_LEN` | `16` | 任务名最大长度 |
| `configUSE_16_BIT_TICKS` | `0` | 使用 32 位 tick |
| `configUSE_TIMERS` | `1` | 软件定时器开启 |
| `configTIMER_TASK_PRIORITY` | `2` | 软件定时器任务优先级 |
| `configTIMER_TASK_STACK_DEPTH` | `512` | 软件定时器任务栈深度 |
| `configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY` | `5` | 可调用 FreeRTOS ISR API 的最高（数值最低）库优先级为 5 |
| `configLIBRARY_LOWEST_INTERRUPT_PRIORITY` | `15` | 最低中断优先级 |
| `configENABLE_FPU` | `0` | 未启用 FreeRTOS FPU 特殊支持 |
| `configENABLE_MPU` | `0` | 未启用 MPU 支持 |

配置原文位于：`Core/Inc/FreeRTOSConfig.h`。

## 3. 当前任务

任务在 `Core/Src/freertos.c` 中由 `MX_FREERTOS_Init()` 创建：

| 任务 | CMSIS 栈属性 | 优先级 | 当前行为 |
|---|---:|---:|---|
| `defaultTask` | `256 * 4` bytes | `osPriorityNormal` | 循环 `osDelay(1)`，占位任务 |
| `ChassisTask` | `512 * 4` bytes | `osPriorityNormal` | 循环 `osDelay(1)`，占位任务 |

CMSIS-RTOS2 的 `stack_size` 字段按字节填写，因此代码中显式乘以 4；这与 `configMINIMAL_STACK_SIZE` 的原生 word 单位不同。

## 4. 启动顺序和当前重要注意点

`Core/Src/main.c` 当前顺序为：

1. `HAL_Init()`、系统时钟和外设初始化；
2. `MotionControl_Init(&huart3, &huart2)`；
3. `MotionControl_RunDefaultSequence()`；
4. `osKernelInitialize()`；
5. `MX_FREERTOS_Init()`；
6. `osKernelStart()`。

因此，当前默认运动序列是在启动 FreeRTOS 调度器之前同步执行的；两个 RTOS 任务目前只是占位循环，并未承载比赛任务状态机。若后续要把底盘控制放入 RTOS，应将运动状态机/周期控制放入 `ChassisTask`，并避免在调度器启动前执行长时间阻塞流程。

## 5. Tick、HAL 和中断关系

- `FreeRTOSConfig.h` 将 `vPortSVCHandler`、`xPortPendSVHandler`、`xPortSysTickHandler` 映射到 CMSIS 标准处理函数。
- 本工程的 HAL 1 ms 时间基准使用 TIM6，具体实现见 `Core/Src/stm32f7xx_hal_timebase_tim.c` 和 `Core/Src/stm32f7xx_it.c` 的 `TIM6_DAC_IRQHandler()`。
- 修改 HAL 时间基准或中断优先级时，必须同时检查 FreeRTOS tick、`configMAX_SYSCALL_INTERRUPT_PRIORITY` 和所有会调用 `FromISR` API 的中断，避免优先级违规或 tick 冲突。

## 6. 本包目录说明

- `Core/Inc/FreeRTOSConfig.h`：应用配置。
- `Core/Src/freertos.c`：CMSIS-RTOS2 任务创建和任务入口。
- `Core/Src/main.c`：内核初始化/启动调用和系统时钟上下文。
- `Core/Src/stm32f7xx_it.c`、`Core/Inc/stm32f7xx_it.h`：相关中断入口。
- `Core/Src/stm32f7xx_hal_timebase_tim.c`：TIM6 HAL 时间基准。
- `Middlewares/Third_Party/FreeRTOS/Source/`：本工程使用的 FreeRTOS Kernel、CMSIS-RTOS2 适配层、`heap_4` 和 ARM CM7 `r0p1` 移植层。
- `MDK-ARM/chassis_motor.uvprojx`：Keil 分组、源文件和 include path。
- `chassis_motor.ioc`：CubeMX 外设/RTOS 生成配置上下文。
- `.vscode/`：VS Code 任务、编译脚本和 IntelliSense include path。
- `PROJECT.md`、`REQUIREMENTS.md`：工程约束和需求背景。

本包保留了 FreeRTOS 源码随附的版权/许可说明（`Source/readme.txt`、`Source/st_readme.txt`）。没有打包 `.o`、`.d`、`.axf`、`.hex` 等生成物，也没有打包个人 Keil `.uvoptx/.uvguix` 文件。

## 7. 重新构建

在完整工程目录中执行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\\.vscode\\build.ps1
```

或用 Keil 打开 `MDK-ARM/chassis_motor.uvprojx`。脚本依赖当前配置的 `G:\\Keil_v5\\UV4\\UV4.exe`，成功时应看到 `0 error(s), 0 warning(s)`，并生成 `MDK-ARM/chassis_motor/chassis_motor.hex`。

