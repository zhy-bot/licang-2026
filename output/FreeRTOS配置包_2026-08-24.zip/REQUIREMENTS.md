# 当前需求与验收标准

## 默认动作

1. 等待 JY60/JY61P 输出有效角度帧。
2. 使能四个电机并建立当前车头航向基准。
3. 四轮尽量同时启动，车体前进 1000 mm。
4. 停止 500 ms。
5. 保持同一车头航向，向左横移 1000 mm。
6. 四轮停止。

## 控制要求

- 前进和横移均使用四麦轮运动学解算。
- 行走使用 `F6` 连续速度模式，每20 ms读取一次当前航向并更新四轮速度，实现运动途中实时锁头。
- 指定距离按下发RPM、实际运行时间和75 mm轮径进行软件积分；保持开环，不读取电机位置、到位或其他返回值。
- 起步和停车使用软件速度斜坡，不通过多条短 `FD` 位置命令实现距离。
- 电机命令采用 x42_v1.3 / Emm V5.0 协议和四轴同步触发。
- 任一位置命令未成功进入发送队列时，不得触发该组运动。
- IMU 无有效数据时禁止启动；运动中 IMU 丢失时立即停车，避免在“实时锁头”失效后继续运行。
- 电机串口异常时进入错误状态并尝试停车。
- `main.c` 不放置麦轮公式、PID、距离换算或驱动协议代码。

## 任意角度斜线运动

- `MotionControl_MovePolarMm(distance_mm, angle_deg)` 支持 -180°～+180° 的任意平移角度。
- 角度定义为：0°前进，+45°左前，+90°左移，+135°左后，180°后退，-45°右前，-90°右移，-135°右后。
- `distance_mm` 表示沿该方向的实际轨迹长度，不是前进和横移分量的简单相加。
- `MotionControl_MoveMm(forward_mm, left_mm)` 保留原接口，并允许两个分量同时非零；目标距离按二维向量长度计算。
- 四个包装接口接收 0°～90° 的相对角度：`MoveLeftFrontMm`、`MoveRightFrontMm`、`MoveLeftRearMm`、`MoveRightRearMm`。
- 斜线运动使用 `MOTION_DIAGONAL_CRUISE_RPM`，当前为 85 RPM；纯轴向运动继续使用 100 RPM。
- 麦轮限幅后的比例必须进入距离积分，避免 45° 或加入锁头修正后软件距离与实际下发速度不一致。

## 默认斜线测试流程

- `DIAGONAL_TEST_ENABLE=1` 时，上电流程为：等待 IMU、使能四轮、等待 500 ms、建立航向基准、等待 100 ms、执行一次测试平移、停车。
- `DIAGONAL_TEST_DISTANCE_MM`、`DIAGONAL_TEST_ANGLE_DEG` 和 `DIAGONAL_TEST_DIRECTION` 位于 `Motor/motion_control.h`，用于现场快速切换测试距离、角度和左前/右前/左后/右后方向。
- `DIAGONAL_TEST_ENABLE=0` 时保留原来的前进 1000 mm、暂停 500 ms、左移 1000 mm动作序列。

## 构建验收

- 在项目根目录运行 `.vscode/build.ps1` 应生成：
  `MDK-ARM/chassis_motor/chassis_motor.hex`。
- Keil 构建日志必须为 `0 Error(s), 0 Warning(s)`。
- VS Code 打开项目根目录后，`Ctrl+Shift+B` 默认运行同一个 Keil 构建任务。

## 尚需实车验收

- 左移时轮向应为：1号反、2号正、3号正、4号反。
- 校准实际轮径、每转脉冲数、前进增益、横移增益和四轮独立增益。
- 确认航向修正符号；若偏差被放大，应翻转 `HEADING_CORRECTION_SIGN`。
- 标定开环速度时间积分与实际地面距离的误差，尤其是麦轮横移滑移误差。
- 观察 `MotionControl_PeriodOverrunCount`；正常应保持为0，否则需要降低控制频率或优化串口发送。
